package com.our.sms.student.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.our.sms.student.vo.StudentVo;



@Service
public class MemberService {

	
	@Autowired
	MemberDao memberDao;

	public int loginConfirm(MemberVo memberVo) {
		
		System.out.println("[MemberService] loginConfirm() INIT ");
		
		return memberDao.getMember(memberVo);
	}
	
	
}
