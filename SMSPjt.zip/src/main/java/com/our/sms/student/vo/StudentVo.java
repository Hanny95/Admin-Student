package com.our.sms.student.vo;

public class StudentVo {
	
	
	private int s_no;
	private String s_id;
	private String s_pw;
	private String s_name;
	private String s_gender;
	private int s_grade;
	private String s_number;
	private String s_major;
	private String s_phone;
	private String s_mail;
	private String s_hobby;
	private int s_absence;
	private String s_reg_date;
	private String s_mod_date;
	
	public StudentVo() {
			
		}
	
	
	public StudentVo(int s_no, String s_id, String s_pw, String s_name, String s_gender, int s_grade, String s_number,
			String s_major, String s_phone, String s_mail, String s_hobby, int s_absence, String s_reg_date,
			String s_mod_date) {

		this.s_no = s_no;
		this.s_id = s_id;
		this.s_pw = s_pw;
		this.s_name = s_name;
		this.s_gender = s_gender;
		this.s_grade = s_grade;
		this.s_number = s_number;
		this.s_major = s_major;
		this.s_phone = s_phone;
		this.s_mail = s_mail;
		this.s_hobby = s_hobby;
		this.s_absence = s_absence;
		this.s_reg_date = s_reg_date;
		this.s_mod_date = s_mod_date;
	}

	public StudentVo(String s_id, String s_pw, String s_name, String s_gender, int s_grade, String s_number, String s_major,
			String s_phone, String s_mail, String s_hobby, int s_absence) {

		this.s_id = s_id;
		this.s_pw = s_pw;
		this.s_name = s_name;
		this.s_gender = s_gender;
		this.s_grade = s_grade;
		this.s_number = s_number;
		this.s_major = s_major;
		this.s_phone = s_phone;
		this.s_mail = s_mail;
		this.s_hobby = s_hobby;
		this.s_absence = s_absence;
	}
	
	
//	public StudentVo(int s_no, String s_name, String s_gender, int s_grade, String s_number, String s_major,
//			String s_phone, String s_mail, String s_hobby, int s_absence, String s_reg_date, String s_mod_date) {
//		
//		this.s_no = s_no;
//		this.s_name = s_name;
//		this.s_gender = s_gender;
//		this.s_grade = s_grade;
//		this.s_number = s_number;
//		this.s_major = s_major;
//		this.s_phone = s_phone;
//		this.s_mail = s_mail;
//		this.s_hobby = s_hobby;
//		this.s_absence = s_absence;
//		this.s_reg_date = s_reg_date;
//		this.s_mod_date = s_mod_date;
//	}
	
	
	
	
//	public StudentVo(String s_name, String s_gender, int s_grade, String s_number, String s_major, String s_phone,
//			String s_mail, String s_hobby, int s_absence) {
//		
//		this.s_name = s_name;
//		this.s_gender = s_gender;
//		this.s_grade = s_grade;
//		this.s_number = s_number;
//		this.s_major = s_major;
//		this.s_phone = s_phone;
//		this.s_mail = s_mail;
//		this.s_hobby = s_hobby;
//		this.s_absence = s_absence;
//	
//	}





	public int getS_no() {
		return s_no;
	}


	public void setS_no(int s_no) {
		this.s_no = s_no;
	}


	public String getS_id() {
		return s_id;
	}


	public void setS_id(String s_id) {
		this.s_id = s_id;
	}


	public String getS_pw() {
		return s_pw;
	}


	public void setS_pw(String s_pw) {
		this.s_pw = s_pw;
	}


	public String getS_name() {
		return s_name;
	}


	public void setS_name(String s_name) {
		this.s_name = s_name;
	}


	public String getS_gender() {
		return s_gender;
	}


	public void setS_gender(String s_gender) {
		this.s_gender = s_gender;
	}


	public int getS_grade() {
		return s_grade;
	}


	public void setS_grade(int s_grade) {
		this.s_grade = s_grade;
	}


	public String getS_number() {
		return s_number;
	}


	public void setS_number(String s_number) {
		this.s_number = s_number;
	}


	public String getS_major() {
		return s_major;
	}


	public void setS_major(String s_major) {
		this.s_major = s_major;
	}


	public String getS_phone() {
		return s_phone;
	}


	public void setS_phone(String s_phone) {
		this.s_phone = s_phone;
	}


	public String getS_mail() {
		return s_mail;
	}


	public void setS_mail(String s_mail) {
		this.s_mail = s_mail;
	}


	public String getS_hobby() {
		return s_hobby;
	}


	public void setS_hobby(String s_hobby) {
		this.s_hobby = s_hobby;
	}


	public int getS_absence() {
		return s_absence;
	}


	public void setS_absence(int s_absence) {
		this.s_absence = s_absence;
	}


	public String getS_reg_date() {
		return s_reg_date;
	}


	public void setS_reg_date(String s_reg_date) {
		this.s_reg_date = s_reg_date;
	}


	public String getS_mod_date() {
		return s_mod_date;
	}


	public void setS_mod_date(String s_mod_date) {
		this.s_mod_date = s_mod_date;
	}




	
	
	
	
}
