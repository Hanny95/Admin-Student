package com.our.sms.student.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
public class MemberController {
	
	@Autowired
	MemberService memberService;
	
	
	/*
	로그인 화면
	*/
//	@RequestMapping(value="/loginForm", method=RequestMethod.GET)
//	public String loginForm() {
//		
//		System.out.println("[MemberController] loginForm() INIT!");
//		
//		return "loginForm";
//	}
	
	/*
	로그인 확인
	*/
//	@RequestMapping(value="/loginConfirm", method=RequestMethod.POST)
//	public String loginConfirm(HttpServletRequest request) {
//		
//		System.out.println("[MemberController] loginConfirm() INIT!");
//		
//		String nextPage = "index";
//		
//		String m_id = request.getParameter("m_id");
//		String m_pw = request.getParameter("m_pw");
//		
//		MemberVo memberVo = new MemberVo();
//		
//		memberVo.setM_id(m_id);
//		memberVo.setM_pw(m_pw);
//		
//		int result = memberService.loginConfirm(memberVo);
//		
//		if (result > 0) {
//			System.out.println("LOGIN SUCCESS!");
//			HttpSession session = request.getSession();   
//			session.setAttribute("loginMember", m_id);
//			nextPage = "redirect:/";
//			
//		} else {
//			System.out.println("LOGIN FAIL!");
//			nextPage = "redirect:/loginForm";
//		}
//		
//		return nextPage;
//	}
//	
	
	
	/*
	로그아웃
	*/
//	@RequestMapping(value="/logout", method=RequestMethod.GET)
//	public String logout(HttpSession session) {  // 다른 방법 (httprequest) 로도 가능 
//		
//		//HttpSession session = request.getSession();
//		session.invalidate();   // session값 날라감
//		
//		return "redirect:/";
//	}
	
}
