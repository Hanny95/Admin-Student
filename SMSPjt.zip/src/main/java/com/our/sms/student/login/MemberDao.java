package com.our.sms.student.login;

import org.springframework.stereotype.Component;



@Component
public class MemberDao {

	public int getMember(MemberVo memberVo) {
	
		System.out.println("[MemberDao] getMember() INIT!");
		
		int result = 0;
		
		String m_id = memberVo.getM_id();
		String m_pw = memberVo.getM_pw();
		
		System.out.println("m_id : " + m_id);
		System.out.println("m_pw : " + m_pw);
		
		if (m_id.equals("abcd") && m_pw.equals("1234")) {
			System.out.println("LOGIN INFO CORRECT!");
			result = 1;
			
		} else {
			System.out.println("LOGIN INFO NOT CORRECT!");
			result = 0;
			
		}
		
		
		return result;
	}

}
