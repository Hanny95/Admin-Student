package com.our.sms.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.our.sms.student.login.MemberService;
import com.our.sms.student.login.MemberVo;
import com.our.sms.student.service.StudentService;
import com.our.sms.student.vo.StudentVo;

@Controller
public class AdminController { 
	
	// service 객체 생성을 자동화해줌 
	@Autowired
	StudentService studentService;
	
	@Autowired
	MemberService memberService;
	/*
	홈
	*/
	@RequestMapping(value = "/ad", method = RequestMethod.GET)
	public String index() {
		System.out.println("index INIT!");
		
		return "adIndex";
	}
	
	
	/*
	학생 목록
	*/
	
	@RequestMapping(value = "/adStdList", method = RequestMethod.GET)
	public String studentList(Model model) {
		System.out.println("studentList() INIT!");
		
		List<StudentVo> studentVos = studentService.getStudentVos();
		model.addAttribute("studentVos", studentVos);
		
		return "adStdList";
	}
	
	/*
	로그인 가기 
	*/
	@RequestMapping(value="/adLoginForm", method=RequestMethod.GET)
	public String loginForm() {
		
		System.out.println("[MemberController] loginForm() INIT!");
		
		return "adLoginForm";
	}
	
	/*
	로그인
	*/
	@RequestMapping(value="/adLoginConfirm", method=RequestMethod.POST)
	public String loginConfirm(HttpServletRequest request) {
		
		System.out.println("[MemberController] loginConfirm() INIT!");
		
		String nextPage = "index";
		
		String m_id = request.getParameter("m_id");
		String m_pw = request.getParameter("m_pw");
		
		MemberVo memberVo = new MemberVo();
		
		memberVo.setM_id(m_id);
		memberVo.setM_pw(m_pw);
		
		int result = memberService.loginConfirm(memberVo);
		
		if (result > 0) {
			System.out.println("LOGIN SUCCESS!");
			HttpSession session = request.getSession();   
			session.setAttribute("loginMember", m_id);
			nextPage = "redirect:/ad";
			
		} else {
			System.out.println("LOGIN FAIL!");
			nextPage = "redirect:/adLoginForm";
		}
		
		return nextPage;
	}
	
	/*
	로그아웃
	*/
	@RequestMapping(value="/adLogout", method=RequestMethod.GET)
	public String logout(HttpSession session) {  // 다른 방법 (httprequest) 로도 가능 
		
		//HttpSession session = request.getSession();
		session.invalidate();   // session값 날라감
		
		return "redirect:/";
	}
	
	/*
	학생 등록 폼 
	*/
	
	@RequestMapping(value = "/adStdAdd", method = RequestMethod.GET)
	public String studentAdd() {
		System.out.println("studentAdd() INIT!");
		
		return "stdAddForm";
	}
	
	/*
	학생 DB 등록
	*/
	// 학생 정보가 있으므로 POST 방식!
	// @RequestParam(value="s_name") String s_name,
	@RequestMapping(value = "/adStdAddConfirm", method = RequestMethod.POST)
	public String studentAddConfirm(HttpServletRequest request, 
			Model model, StudentVo studentVo) {
	
		System.out.println("studentAddConfirm() INIT!");
		
			
		int result = studentService.addStudent(studentVo);
		model.addAttribute("result", result);  // 결과를 jsp로 보냄 
		
		// 바로 list로 가지않고 업데이트 필요함
		//return "redirect:/stdList";
		return "redirect:/ad";
	}
	
	
	/*
	학생 정보 수정 폼
	*/
	
	// 1. HttpServletRequest request
	// 2. @RequestParam(int s_no)
	// 3. (StudentVo studentVo) 객체를 넣어주기 
	 
	@RequestMapping(value = "/adStdModify", method = RequestMethod.GET)
	public String studentModify(StudentVo studentVo, Model model) {
		System.out.println("studentModify() INIT!");
		

		StudentVo vo = studentService.getStudentVo(studentVo.getS_no());
		model.addAttribute("studentVo", vo);
		
		return "stdModifyForm";
	}
	
	/*
	학생 DB 정보 수정
	*/
	
	@RequestMapping(value = "/adStdModifyConfirm", method = RequestMethod.POST)
	public String studentModifyConfirm(Model model, StudentVo studentVo) {
		System.out.println("studentModifyConfirm() INIT!");
		
		int result = studentService.modifyStudentVo(studentVo);
		model.addAttribute("result", result);
		 
		return "redirect:/adStdList";
	}
	
	/*
	학생 정보 삭제
	*/
	
	@RequestMapping(value = "/adStdDelete", method = RequestMethod.GET)
	public String studentDelete(StudentVo studentVo) {
		System.out.println("studentDelete() INIT!");
		
		
		int result = studentService.deleteStudentVo(studentVo);
		
		
		return "redirect:/adStdList";  // 확인 삭제 페이지 만들면 좋음 
	}
	

	

}
